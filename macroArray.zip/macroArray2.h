#ifndef MACROARRAY2_H
#define MACROARRAY2_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

extern int __strArrLen(const char* str);
extern bool decideFormat(char* format,const char* type);

#define arrlen(a) (sizeof(a)/sizeof(a[0]))

#define Arr_Max 100

#define arrWithSize(a) a , arrlen(a)

#define Array(T) T##Array
//--------------------------------------------------------------------

#define __ExpendMyArray(T) \
__DefMyArr(T) \
__DefMySetFormat(T) \
__DefMyAddItem(T) \
__DefMyPrintArr(T) \
__DefMyIniArrFuc(T) 



//--------------------------------------------------------------------


#define __DefMyArr(T) \
typedef struct T##Array *p##T##Array;\
typedef struct T##Array\
{\
	T array[Arr_Max];\
	int length;\
	char format[6];\
	bool isObject;\
	void (*setFormat)(p##T##Array,const char*);\
	void (*print)(p##T##Array);\
	void (*addItem)(p##T##Array,T);\
	T (*construct)(T);\
}T##Array;

#define IniEptArr(T,arr) Ini##T##Arr( &arr ,NULL,0)

#define __DefMyIniArrFuc(T) \
void Ini##T##Arr( T##Array *arr, T c_array[] , int len)\
{\
	arr->length = len;\
	int i;\
	arr->isObject = decideFormat(arr->format,#T );\
	arr->setFormat = &setEx##T##Format;\
	arr->addItem = &add##T##Item;\
	arr->print = &printEx##T##Arr;\
	arr->construct = &construct##T;\
	free(c_array);\
}

#define __DefMyPrintArr(T) \
void printEx##T##Arr( T##Array *arr)\
{\
	int i=0;\
	char f[10];\
	printf("{");\
	for(i=0;i<arr->length;i++)\
	{\
		printf(" ");\
		arr->array[i]->print(arr->array[i]);\
		printf(" ");\
	}\
	printf("}\n");\
}


#define __DefMySetFormat(T)\
void setEx##T##Format( T##Array *arr, const char *format)\
{\
	strcpy(arr->format,format);\
}

#define __DefMyAddItem(T)\
void add##T##Item( T##Array *arr, T thing )\
{\
	arr->array[arr->length] = arr->construct(thing);\
	arr->length++;\
}

#endif




	
