#ifndef MACROARRAY_H
#define MACROARRAY_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef enum {false,true}bool;

int __strArrLen(const char* str);
bool decideFormat(char* format,const char* type);

//#define arrlen(a) (sizeof(a)/sizeof(a[0]))

#define Arr_Max 100

//#define arrWithSize(a) a , arrlen(a)

#define Array(T) T##Array
//--------------------------------------------------------------------

#define __ExpendArray(T) \
__DefArr(T) \
__DefSetFormat(T) \
__DefAddItem(T) \
__DefPrintArr(T) \
__DefIniArrFuc(T) \
__DefStrToArr(T) 



//--------------------------------------------------------------------

//����ṹ�� 
#define __DefArr(T) \
typedef struct T##Array *p##T##Array;\
typedef struct T##Array\
{\
	T array[Arr_Max];\
	int length;\
	char format[12];\
	bool isObject;\
	void (*setFormat)(p##T##Array,const char*);\
	void (*print)(p##T##Array);\
	void (*addItem)(p##T##Array,T);\
}T##Array;

//�����򻯳�ʼ���ĺ� 
#define IniArr(t,arr,str) Ini##t##Arr( &arr , __strTo##t##Arr(str), __strArrLen(str) )

//�����ʼ���ṹ��ĺ��� 
#define __DefIniArrFuc(T) \
void Ini##T##Arr( T##Array *arr, T c_array[] , int len)\
{\
	arr->length = len;\
	int i;\
	arr->isObject = decideFormat(arr->format,#T );\
	arr->setFormat = &setEx##T##Format;\
	arr->addItem = &add##T##Item;\
	arr->print = &printEx##T##Arr;\
	if(!arr->isObject)\
	{\
		for(i=0;i<len;i++)\
		{\
			arr->array[i] = c_array[i];\
		}\
	}\
	free(c_array);\
}

//���� ת��һ���ַ�������Ӧ���͵����� �ĺ��� 
#define __DefStrToArr(T) \
T *__strTo##T##Arr(const char* str)\
{\
	int i=0,len=__strArrLen(str),t;\
	T *temp;\
	char type[] = #T ;\
	char format[6];\
	char *pstr = str;\
	decideFormat(format,type);\
	temp = (T *)malloc(len*sizeof(T));\
	for(i=0;i<len;i++)\
	{\
		sscanf(pstr,format,temp+i);\
		while(1)\
		{\
			pstr++;\
			if(pstr[0]==','||pstr[0]=='\0')\
				break;\
		}\
		pstr++;\
	}\
	return temp;\
}


//�����ӡ����ĺ��� 
#define __DefPrintArr(T)\
void printEx##T##Arr( T##Array *arr)\
{\
	int i=0;\
	char f[10];\
	if(!arr->isObject)\
	{\
		sprintf(f," %s ",arr->format);\
		printf("{");\
		for(i=0;i<arr->length;i++)\
			printf(f,arr->array[i]);\
		printf("}\n");\
	}\
}

//������������Ԫ����printf��ӡ�ĸ�ʽ�ĺ��� 
#define __DefSetFormat(T)\
void setEx##T##Format( T##Array *arr, const char *format)\
{\
	strcpy(arr->format,format);\
}
//����������������Ԫ�صĺ��� 
#define __DefAddItem(T)\
void add##T##Item( T##Array *arr, T thing )\
{\
	arr->array[arr->length] = thing;\
	arr->length++;\
}

//������һ���ַ�������������ĳ��ȣ�ͨ�������ţ� 
int __strArrLen(const char* str)
{
	int len = 0,i;
	for(i=0;str[i]!='\0';i++)
	{
		if(str[i]==',')
		{
			len++;
			str[i] == ' ';
		}
	}
	return ++len;
}

//�Ѹ���������ת��Ϊ��Ӧ��printf�õı�ʾ�� 
bool decideFormat(char* format,const char* type)
{
	if(strcmp(type,"int")==0)strcpy(format,"%d");
	else if(strcmp(type,"long")==0)strcpy(format,"%ld");
	else if(strcmp(type,"long long")==0)strcpy(format,"%lld");
	else if(strcmp(type,"float")==0)strcpy(format,"%f");
	else if(strcmp(type,"double")==0)strcpy(format,"%lf");
	else if(strcmp(type,"long double")==0)strcpy(format,"%llf");
	else if(strcmp(type,"char")==0)strcpy(format,"%c");
	else 
	{
		strcpy(format,"%p");
		return true;
	}
	return false;
}

#endif




	
