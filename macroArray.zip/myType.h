typedef struct Mytype *pMytype;
typedef struct Mytype{
	int a;
	double b;
	void (*print)(pMytype);
	void (*copy)(pMytype,pMytype);
}Mytype;
pMytype constructMytype(pMytype pm_src);
void myTypePrint(pMytype pm)
{
	printf("{a=%d b=%.1lf}",pm->a,pm->b);
}
void myTypeCopy(pMytype pm_this,pMytype pm_src)
{
	pm_this->a = pm_src->a;
	pm_this->b = pm_src->b;
}
pMytype getMytype(int a1,int b1)
{
	pMytype obj = (pMytype)malloc(sizeof(Mytype));
	obj->a = a1;
	obj->b = b1;
	obj->print = &myTypePrint;
	obj->copy = &myTypeCopy;
	return obj;
}
pMytype constructpMytype(pMytype pm_src)
{
	return getMytype(pm_src->a,pm_src->b);
}

